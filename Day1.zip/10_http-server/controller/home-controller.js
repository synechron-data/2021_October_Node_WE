module.exports.index = (req, res) => {
    fs.readFile('./index.html', (err, htmlContent) => {
        if (err) {
            res.setHeader("content-type", "text/plain");
            res.end("Page Not Found");
        }

        res.setHeader("content-type", "text/html");
        res.write(htmlContent);
        res.end();
    })
};