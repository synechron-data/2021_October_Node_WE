// Global Objects
// console.log(this);
// console.log(module);

// console.log(process);
// console.log(process.stdin);
// console.log(process.stdout);
// console.log(process.cwd());

// console.log(__dirname);
// console.log(__filename);

// var i = 10;
// console.log(i);
// console.log(typeof i);

// function add(x = 0, y = 0) {
//     return x + y;
// }

// console.log(add(2, 3));
// console.log(add(2));
// console.log(add());

// const Employee = (function () {
//     function Employee(name) {
//         this.name = name;
//     }

//     Employee.prototype.getName = function () {
//         return this.name;
//     }

//     Employee.prototype.setName = function (value) {
//         this.name = value;
//     }

//     return Employee;
// })();

// var e1 = new Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

class Person {
    constructor(name) {
        this.name = name;
    }

    getName() {
        return this.name;
    }

    setName(value) {
        this.name = value;
    }
}

var p1 = new Person("Manish");
console.log(p1.getName());
p1.setName("Ramakant");
console.log(p1.getName());
