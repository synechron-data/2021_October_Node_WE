// require('./lib.js');

// const lib = require('./lib.js');
// console.log(lib);

// console.log("Firstname: ", lib.firstname);
// console.log("Lastname: ", lib.lastname);
// console.log(lib.log("Hi from App Module"));

// const lib = require('./lib.js');
// var p1 = new lib.Person("Manish");

// Destructuring
const { Person } = require('./lib.js');
var p1 = new Person("Manish");
console.log(p1.getName());
p1.setName("Ramakant");
console.log(p1.getName());