const Logger = require('./Logger');
const logger = new Logger();

exports.log = function (message) {
    logger.log(message);
}