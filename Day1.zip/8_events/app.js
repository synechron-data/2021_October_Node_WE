// // Every action which you perform on your computer system is an event

// var events = require('events');

// var eEmitter = new events.EventEmitter();

// // Subscribe
// eEmitter.on('test', ()=>{
//     console.log("Listener Called....");
// });

// eEmitter.addListener('test', ()=>{
//     console.log("Listener Called....");
// });

// // Trigger

// eEmitter.emit('test');          // Publishing an event

// ---------------------------------------------------------------------
const StringEmitter = require('./StringEmitter');
const sEmitter = new StringEmitter();

// var s = sEmitter.getString();
// console.log(s);

// setInterval(function () {
//     var s = sEmitter.getString();
//     console.log(s);
// }, 2000);

// sEmitter.pushString(function (s) {
//     console.log(s);
// });

// sEmitter.pushString(function (s) {
//     console.log("F1 - ", s);
// });

// sEmitter.pushString(function (s) {
//     console.log("F2 - ", s);
// });

sEmitter.on('data', (s) => {
    console.log("S1 - ", s);
});

function S2(s) {
    console.log("S2 - ", s);
}

sEmitter.on('data', S2);

setTimeout(() => {
    sEmitter.removeListener('data', S2);
}, 5000);