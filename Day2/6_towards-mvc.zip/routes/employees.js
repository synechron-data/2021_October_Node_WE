const express = require('express');
const router = express.Router();

const empCtrl = require('../controllers/employees-controller');

router.get('/', empCtrl.index);

router.get('/details', empCtrl.details);

router.get('/details/:empid', empCtrl.details);

module.exports = router;