const da = require('../data-access');
const User = require('../models/user');

exports.index = function (req, res, next) {
    da.getAllUsers().then(result => {
        res.render('users/index', { title: 'Users View', users: result, message: "" });
    }, eMsg => {
        res.render('users/index', { title: 'Users View', users: [], message: eMsg });
    });
}

exports.details = function (req, res, next) {
    da.getUser(req.params.userid).then(result => {
        res.render('users/details', { title: 'User Details View', user: result, message: "" });
    }, eMsg => {
        res.render('users/details', { title: 'User Details View', user: null, message: eMsg });
    });
}

exports.create_get = function (req, res, next) {
    res.render('users/create', { title: 'Create User View', user: null, message: "" });
};

exports.create_post = function (req, res, next) {
    var uname = req.body.uname;
    var email = req.body.email;

    var user = new User(uname, email);

    da.insertUser(user).then((result) => {
        res.redirect('/users');
    }, (eMsg) => {
        res.render('users/create', { title: 'Create User View', user: null, message: eMsg });
    });
}

exports.edit_get = function (req, res, next) {
    da.getUser(req.params.userid).then(result => {
        res.render('users/edit', { title: 'Edit User View', user: result, message: "" });
    }, eMsg => {
        res.render('users/edit', { title: 'Edit User View', user: null, message: eMsg });
    });
}

exports.edit_post = function (req, res, next) {
    var uname = req.body.uname;
    var email = req.body.email;

    var user = new User(uname, email);

    da.updateUser(req.params.userid, user).then((result) => {
        res.redirect('/users');
    }, (eMsg) => {
        res.render('users/edit', { title: 'Edit User View', user: user, message: eMsg });
    });
}

exports.delete_get = function (req, res, next) {
    da.getUser(req.params.userid).then((result) => {
        res.render('users/delete', { title: 'Delete User View', user: result, message: "" });
    }, (eMsg) => {
        res.render('users/delete', { title: 'Delete User View', user: null, message: eMsg });
    });
}

exports.delete_post = function (req, res, next) {
    da.deleteUser(req.params.userid).then((msg) => {
        res.redirect('/users');
    }, (eMsg) => {
        res.render('users/delete', { title: 'Delete User View', user: null, message: eMsg });
    });
}