var express = require('express');
var cors = require('cors');

var router = express.Router();

const usersApiCtrl = require('../controllers/users-api-controller');

router.use(cors());

router.get('/', usersApiCtrl.getUsers);

module.exports = router;
